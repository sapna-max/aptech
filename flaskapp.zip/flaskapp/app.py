from flask import Flask, jsonify
import awsgi

app = Flask(__name__)

@app.route('/')
def home():
    return jsonify({
        "message": "Flask App Running on AWS Lambda"
    })

# Lambda Handler
def lambda_handler(event, context):
    return awsgi.response(app, event, context)